import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Initialize storage bucket
export const initializeStorage = async () => {
  const { data: buckets, error } = await supabase.storage.listBuckets();
  
  if (!buckets?.find(bucket => bucket.name === 'pdfs')) {
    const { error: createError } = await supabase.storage.createBucket('pdfs', {
      public: false,
      fileSizeLimit: 10485760, // 10MB
    });
    
    if (createError) {
      console.error('Error creating bucket:', createError);
      throw createError;
    }
  }
};