import React, { useEffect, useState } from 'react';
import { initializeStorage } from './lib/supabase';
import { FileUpload } from './components/FileUpload';
import { PDFViewer } from './components/PDFViewer';
import { Chat } from './components/Chat';
import { ErrorBoundary } from './components/ErrorBoundary';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

function App() {
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    initializeStorage().catch(console.error);
  }, []);

  const handleSendMessage = async (message: string) => {
    if (!message.trim()) return;

    const newMessages = [...messages, { role: 'user', content: message }];
    setMessages(newMessages);

    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_OPENROUTER_API_KEY}`,
        },
        body: JSON.stringify({
          model: 'openai/gpt-3.5-turbo',
          messages: newMessages,
        }),
      });

      const data = await response.json();
      setMessages([...newMessages, { role: 'assistant', content: data.choices[0].message.content }]);
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages([...newMessages, { role: 'assistant', content: 'Sorry, I encountered an error. Please try again.' }]);
    }
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left side - PDF Upload and View */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="mb-6">
                <FileUpload onUploadComplete={setPdfUrl} />
              </div>
              
              {pdfUrl && (
                <div className="mt-6">
                  <PDFViewer url={pdfUrl} />
                </div>
              )}
            </div>

            {/* Right side - Chat Interface */}
            <div className="bg-white rounded-lg shadow-lg p-6 h-[700px]">
              <Chat messages={messages} onSendMessage={handleSendMessage} />
            </div>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
}

export default App;